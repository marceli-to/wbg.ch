<section class="site-content">
  <div class="project-list">
    <?php $__currentLoopData = $projects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $project): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <?php $__currentLoopData = $project->previewImages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <figure class="project-teaser">
          <h2><?php echo e($project->name); ?></h2>
          <?php if($project->category_id == 3): ?>
            <a href="/projekte/<?php echo e($project->category_id); ?>/panoptikum/<?php echo e($project->subcategory_id); ?>/<?php echo e(mb_strtolower($subCategories[$project->subcategory_id], 'UTF-8')); ?>/!#<?php echo e(str_slug($project->name)); ?>" title="<?php echo e($project->name); ?>">
              <img src="/assets/img/preview.png" data-src="<?php echo ImageHelper::preview($image->name); ?>" class="lazyload" height="512" width="380" alt="<?php echo e($project->name); ?>">
            </a>
          <?php else: ?>
            <a href="/projekt/<?php echo AppHelper::slug($project); ?>" title="<?php echo e($project->name); ?>">
              <img src="/assets/img/preview.png" data-src="<?php echo ImageHelper::preview($image->name); ?>" class="lazyload" height="512" width="380" alt="<?php echo e($project->name); ?>">
            </a>
          <?php endif; ?>
        </figure>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  </div>
</section><?php /**PATH /Users/marceli.to/Jamon.digital/Webroot/wbg.ch/resources/views/web/partials/projects/list.blade.php ENDPATH**/ ?>