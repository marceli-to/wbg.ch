<?php $__env->startSection('content'); ?>
<?php echo $__env->make('web.partials.projects.list', array('projects' => $projects), \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('web.layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/marceli.to/Jamon.digital/Webroot/wbg.ch/resources/views/web/projects/index.blade.php ENDPATH**/ ?>