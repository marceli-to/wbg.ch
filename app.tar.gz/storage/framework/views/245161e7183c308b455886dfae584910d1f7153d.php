<?php $__env->startSection('content'); ?>
<section class="site-content">
  <div class="clients">
    <?php $__currentLoopData = $clients; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $client_group): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <div class="client-group">
        <div class="client-index"><?php echo e($key); ?></div>
        <?php $__currentLoopData = $client_group; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $client): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <div class="client">
            <?php if($client->project_id): ?>
              <?php if($client->project->category_id == 3): ?>
                <a 
                  href="/projekte/<?php echo e($client->project->category_id); ?>/panoptikum/<?php echo e($client->project->subcategory_id); ?>/-/!#<?php echo e(str_slug($client->project->name)); ?>"
                  title="<?php echo e($client->project->name); ?>"
                  rel="canonical">
              <?php else: ?>
                <a href="/projekt/<?php echo AppHelper::slug($client->project); ?>" title="<?php echo e($client->project->name); ?>" rel="canonical">
              <?php endif; ?>
                <?php echo e($client->name); ?><?php if($client->location): ?>, <?php echo e($client->location); ?> <?php endif; ?>
              </a>
            <?php else: ?>
              <?php echo e($client->name); ?><?php if($client->location): ?>, <?php echo e($client->location); ?> <?php endif; ?>
            <?php endif; ?>
          </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  </div>
</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('web.layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/marceli.to/Jamon.digital/Webroot/wbg.ch/resources/views/web/profile/clients.blade.php ENDPATH**/ ?>