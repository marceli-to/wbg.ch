<?php $__env->startSection('content'); ?>
<section class="site-content">
  <?php if($intro): ?>
    <div class="intro"><?php echo $intro->text; ?></div>
  <?php endif; ?>
  <div class="ratio-boxes">
    <?php $__currentLoopData = $grids; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $g): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <?php if($g['key'] == '1fr'): ?>
        <?php if(isset($g['elements'])): ?>
          <?php echo $__env->make('web.partials.boxes.home.1fr', array('elements' => $g['elements']), \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php endif; ?>
      <?php endif; ?>
      <?php if($g['key'] == '1fr-1fr_stacked'): ?>
        <?php if(isset($g['elements'])): ?>
          <?php echo $__env->make('web.partials.boxes.home.1fr-1fr_stacked', array('elements' => $g['elements']), \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php endif; ?>
      <?php endif; ?>
      <?php if($g['key'] == '1fr_stacked-1fr'): ?>
        <?php if(isset($g['elements'])): ?>
          <?php echo $__env->make('web.partials.boxes.home.1fr_stacked-1fr', array('elements' => $g['elements']), \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php endif; ?>
      <?php endif; ?>
      <?php if($g['key'] == '1fr-wide'): ?>
        <?php if(isset($g['elements'])): ?>
          <?php echo $__env->make('web.partials.boxes.home.1fr-wide', array('elements' => $g['elements']), \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php endif; ?>
      <?php endif; ?>
      <?php if($g['key'] == '2x1fr-wide'): ?>
        <?php if(isset($g['elements'])): ?>
          <?php echo $__env->make('web.partials.boxes.home.2x1fr-wide', array('elements' => $g['elements']), \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php endif; ?>
      <?php endif; ?>
      <?php if($g['key'] == '2x1fr'): ?>
        <?php if(isset($g['elements'])): ?>
          <?php echo $__env->make('web.partials.boxes.home.2x1fr', array('elements' => $g['elements']), \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php endif; ?>
      <?php endif; ?>
      <?php if($g['key'] == '1fr-portrait'): ?>
        <?php if(isset($g['elements'])): ?>
          <?php echo $__env->make('web.partials.boxes.home.1fr-portrait', array('elements' => $g['elements']), \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php endif; ?>
      <?php endif; ?>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  </div>
</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('web.layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/marceli.to/Jamon.digital/Webroot/wbg.ch/resources/views/web/home/index.blade.php ENDPATH**/ ?>