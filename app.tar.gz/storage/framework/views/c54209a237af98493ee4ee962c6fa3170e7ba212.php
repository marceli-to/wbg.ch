<div class="box-1fr">
  <div>
    <div class="box__c">
      <div>
        <?php if(isset($elements[0])): ?>
          <?php if($elements[0]->news): ?>
            <?php echo $__env->make('web.partials.boxes.article', array('news' => $elements[0]->news), \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
          <?php endif; ?>
          <?php if($elements[0]->projectimage): ?>
            <a href="/projekt/<?php echo AppHelper::slug($elements[0]->projectimage->project); ?>" rel="canonical" title="<?php echo e($elements[0]->projectimage->project->name); ?>">
              <img class="lazyload" data-src="<?php echo ImageHelper::get($elements[0]->projectimage->name, 'lg'); ?>" height="560" width="860" alt="<?php echo e($elements[0]->projectimage->caption); ?>">
            </a>
          <?php endif; ?>
        <?php endif; ?>
      </div>
    </div>
  </div>
</div><?php /**PATH /Users/marceli.to/Jamon.digital/Webroot/wbg.ch/resources/views/web/partials/boxes/home/1fr.blade.php ENDPATH**/ ?>