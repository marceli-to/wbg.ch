<article>
  <div>
    <?php if($news->title): ?>
      <h2><?php echo e($news->title); ?></h2>
    <?php endif; ?>
    <?php if($news->text): ?>
      <p><?php echo nl2br(e($news->text)); ?></p>
    <?php endif; ?>
    <?php if($news->link): ?>
      <a href="<?php echo e($news->link); ?>" <?php echo e($news->linkNewWindow ? 'target="_blank"' : ''); ?> class="icon-arrow">
        <?php if($news->linkText): ?>
          <?php echo e($news->linkText); ?>

        <?php else: ?>
          Mehr
        <?php endif; ?>
      </a>
    <?php endif; ?>
  </div>
</article><?php /**PATH /Users/marceli.to/Jamon.digital/Webroot/wbg.ch/resources/views/web/partials/boxes/article.blade.php ENDPATH**/ ?>