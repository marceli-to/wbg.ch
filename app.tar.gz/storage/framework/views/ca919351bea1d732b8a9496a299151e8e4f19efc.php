<?php $__env->startSection('content'); ?>
<?php if($isPanoptikum): ?>
<section class="site-content">
  <div class="project-list project-list--panoptikum">
    <?php $__currentLoopData = $projects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $projectSub): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <h2><?php echo e($subCategories[$key]); ?></h2>
      <?php $__currentLoopData = $projectSub; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $project): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php $__currentLoopData = $project->previewImages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <figure class="project-teaser">
            <a href="/projekte/<?php echo e($project->category_id); ?>/panoptikum/<?php echo e($project->subcategory_id); ?>/<?php echo e(mb_strtolower($subCategories[$key], 'UTF-8')); ?>/!#<?php echo e(str_slug($project->name)); ?>" title="<?php echo e($project->name); ?>">
              <img src="/assets/img/preview.png" data-src="<?php echo ImageHelper::preview($image->name); ?>" class="lazyload" height="512" width="380" alt="<?php echo e($project->name); ?>">
            </a>
          </figure>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  </div>
</section>
<?php else: ?>
  <?php echo $__env->make('web.partials.projects.list', array('projects' => $projects), \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php endif; ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('web.layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/marceli.to/Jamon.digital/Webroot/wbg.ch/resources/views/web/projects/category.blade.php ENDPATH**/ ?>