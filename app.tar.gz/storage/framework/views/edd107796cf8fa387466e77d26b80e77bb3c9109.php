<!doctype html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>wbg.ch</title>
<meta name="csrf-token" value="<?php echo e(csrf_token()); ?>" />
<meta name="format-detection" content="telephone=no">
<link href="<?php echo e(asset('assets/css/app.css')); ?>" type="text/css" rel="stylesheet" />
<script src="<?php echo e(asset('assets/js/modernizr.min.js')); ?>"></script>
</head>
<body>
<header class="site-header js-header">
  <div>
    <a href="javascript:;" class="btn-menu js-btn-menu"></a>
    <div class="span header-logo">
      <a href="/" class="logo" title="WBG - Home">WBG</a>
      
    </div>
    <div class="span header-title">
      <h1 class="page-title"><?php if(isset($pageTitle)): ?> <?php echo e($pageTitle); ?> <?php else: ?> &nbsp; <?php endif; ?></h1>
      
    </div>
    <div class="span header-navigation">
      <nav class="header" role="navigation">
        <ul>
          <li>
            <a href="<?php echo e(route('project.index')); ?>" 
               title="Projekte"
               class="<?php echo e(request()->routeIs('project.*') ? 'is-active' : ''); ?>">
               Projekte
            </a>
          </li>
          <li>
            <a href="<?php echo e(route('profile.attitude')); ?>"
               title="Profil"
               class="<?php echo e(request()->routeIs('profile.*') ? 'is-active' : ''); ?>">
               Profil
            </a>
          </li>
          <li>
            <a href="<?php echo e(route('team')); ?>"
               title="Team"
               class="<?php echo e(request()->routeIs('team') ? 'is-active' : ''); ?>">
               Team
            </a>
          </li>
          <li>
            <a href="<?php echo e(route('contact')); ?>"
               title="Team"
               class="<?php echo e(request()->routeIs('contact') ? 'is-active' : ''); ?>">
               Kontakt
            </a>
          </li>
        </ul>
      </nav>
      
    </div>
  </div>
</header>
<main role="main">
  <nav class="sidebar js-menu">
    <ul class="is-project">
      <li>
        <a href="javascript:;" class="<?php echo e(request()->routeIs('project.*') ? 'is-active' : ''); ?> js-btn-toggle-sub">Projekte</a>
        <ul style="<?php echo e(request()->routeIs('project.*') ? 'display:block' : 'display:none'); ?>">
          <?php $__currentLoopData = $menu['projects']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $menu_project): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li>
              <a href="<?php echo e($menu_project['slug']); ?>" 
                 class="<?php echo e($menu_project['is-active'] ? 'is-active' : ''); ?>">
                 <?php echo e($menu_project['category']); ?>

              </a>
              <ul class="<?php echo e($menu_project['is-active'] ? 'is-visible' : ''); ?>">
                <?php $__currentLoopData = $menu_project['items']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $menu_item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <li>
                    <a 
                      href="<?php echo e($menu_item['slug']); ?>"
                      class="<?php echo e($menu_item['is-active'] ? 'is-active hide-sm' : 'hide-sm'); ?>">
                      <?php echo e($menu_item['name']); ?>

                    </a>
                  </li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </ul>
            </li>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
      </li>
    </ul>
    <ul class="is-profile">
      <li>
        <a href="javascript:;" 
           class="js-btn-toggle-sub <?php echo e(request()->routeIs('profile.*') ? 'is-active' : ''); ?>">
           Profil
        </a>
        <ul style="<?php echo e(request()->routeIs('profile.*') ? 'display:block' : 'display:none'); ?>">
          <li>
            <a href="<?php echo e(route('profile.attitude')); ?>"
                class="<?php echo e(request()->routeIs('profile.attitude') ? 'is-active' : ''); ?>">
              Haltung
            </a>
          </li>
          <li>
            <a href="<?php echo e(route('profile.competences')); ?>"
                class="<?php echo e(request()->routeIs('profile.competences') ? 'is-active' : ''); ?>">
              Kompetenzen
            </a>
          </li>
          <li>
            <a href="<?php echo e(route('profile.clients')); ?>"
                class="<?php echo e(request()->routeIs('profile.clients') ? 'is-active' : ''); ?>">
              Kunden
            </a>
          </li>
          <li>
            <a href="<?php echo e(route('profile.imprint')); ?>"
                class="<?php echo e(request()->routeIs('profile.imprint') ? 'is-active' : ''); ?>">
              Impressum
            </a>
          </li>
        </ul>
      </li>
    </ul>
    <ul class="hide-md">
      <li>
        <a href="<?php echo e(route('team')); ?>" class="<?php echo e(request()->routeIs('team') ? 'is-active' : ''); ?>">Team</a>
      </li>
    </ul>
    <ul class="hide-md">
      <li>
        <a href="<?php echo e(route('contact')); ?>" class="<?php echo e(request()->routeIs('contact') ? 'is-active' : ''); ?>">Kontakt</a>
      </li>
    </ul>
  </nav>
  <?php echo $__env->yieldContent('content'); ?>
</main>
<footer class="site-footer js-footer">
  WBG AG – VISUELLE KOMMUNIKATION<br>BINZSTRASSE 39, CH-8045 ZÜRICH, +41 44 269 43 43, MAIL@WBG.CH
</footer>
<script src="<?php echo e(asset('assets/js/app.js')); ?>" type="text/javascript"></script>
</body>
<!-- made with ❤ by marceli.to -->
</html><?php /**PATH /Users/marceli.to/Jamon.digital/Webroot/wbg.ch/resources/views/web/layout/app.blade.php ENDPATH**/ ?>