<div class="box-2x1fr">
  <div>
    <div class="box__b">
      <div>
        <?php if(isset($elements[0])): ?>
          <?php if($elements[0]->news): ?>
            <?php echo $__env->make('web.partials.boxes.article', array('news' => $elements[0]->news), \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
          <?php endif; ?>
          <?php if($elements[0]->image): ?>
            <?php if($elements[0]->image->url): ?>
              <a href="<?php echo e($elements[0]->image->url); ?>" target="_blank" title="<?php echo e($elements[0]->image->caption); ?>">
                <img src="<?php echo ImageHelper::get($elements[0]->image->name, 'lg'); ?>" height="560" width="430" alt="<?php echo e($elements[0]->image->caption); ?>">
              </a>
            <?php else: ?>
              <img src="<?php echo ImageHelper::get($elements[0]->image->name, 'lg'); ?>" height="560" width="430" alt="<?php echo e($elements[0]->image->caption); ?>">
            <?php endif; ?>
          <?php endif; ?>
        <?php endif; ?>
      </div>
    </div>
  </div>
  <div>
    <div class="box__b">
      <div>
        <?php if(isset($elements[1])): ?>
          <?php if($elements[1]->news): ?>
            <?php echo $__env->make('web.partials.boxes.article', array('news' => $elements[1]->news), \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
          <?php endif; ?>
          <?php if($elements[1]->image): ?>
            <?php if($elements[1]->image->url): ?>
              <a href="<?php echo e($elements[1]->image->url); ?>" target="_blank" title="<?php echo e($elements[1]->image->caption); ?>">
                <img src="<?php echo ImageHelper::get($elements[1]->image->name, 'lg'); ?>" height="560" width="430" alt="<?php echo e($elements[1]->image->caption); ?>">
              </a>
            <?php else: ?>
              <img src="<?php echo ImageHelper::get($elements[1]->image->name, 'lg'); ?>" height="560" width="430" alt="<?php echo e($elements[1]->image->caption); ?>">
            <?php endif; ?>
          <?php endif; ?>
        <?php endif; ?>
      </div>
    </div>
  </div>
</div><?php /**PATH /Users/marceli.to/Jamon.digital/Webroot/wbg.ch/resources/views/web/partials/boxes/project/2x1fr.blade.php ENDPATH**/ ?>