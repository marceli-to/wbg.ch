<?php $__env->startSection('content'); ?>
<section class="site-content"></section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('web.layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/marceli.to/Jamon.digital/Webroot/wbg.ch/resources/views/web/profile/attitude.blade.php ENDPATH**/ ?>